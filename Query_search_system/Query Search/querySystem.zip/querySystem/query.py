import json
from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def search():
   return render_template('searchQuery.html')

@app.route('/result', methods = ['POST', 'GET'])
def result():
   if request.method == 'POST':
      result = request.form
      return render_template("result.html", result = result)

@app.route('/searchResults', methods = ['POST', 'GET'])
def searchResults():
   if request.method == 'POST':
      with open('result.json') as json_file:
         threads = json.load(json_file)
         for t in threads:
            print("Thread id: " + t)
            posts = threads[t]
            print(posts)
            for p in posts:
               # print(p)
               print("id: " + p['id'])
               print("post: " + p['post'])
               print("tag: " + p['tag'])
            print('\n')

   return render_template("searchResults.html", threads = threads)

if __name__ == '__main__':
   app.run(debug = True)